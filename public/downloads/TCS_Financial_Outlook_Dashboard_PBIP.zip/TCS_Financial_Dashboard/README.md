# TCS Financial Outlook Dashboard

This Power BI Desktop project provides a four-page executive finance report. It uses the supplied workbook for FY2018–FY2025 history, official TCS reporting for the FY2026 actual baseline, and explicit Base/Bull/Bear analytical scenarios for FY2027–FY2028.

## Report pages

1. **Executive Overview** — prominent Scenario and Forecast Year slicers, aligned KPI cards for Revenue, Calculated EBITDA proxy, Adjusted PAT, and Organic FCF, plus selected-output and revenue-outlook charts.
2. **Trend & Profitability** — historical revenue, EBITDA, profit, and free-cash-flow analysis.
3. **Scenario & Drivers** — labelled Bull/Base/Bear assumption comparison and driver detail.
4. **Financial Detail** — auditable year-by-metric values and a metric comparison.

The Scenario and Fiscal Year controls use explicit labels. Standard Power BI visual cross-filtering is enabled for all analytical charts and tables.

## Open and build

1. Install **Power BI Desktop** (current Microsoft Store or MSI release), enable **File > Options and settings > Options > Preview features > Power BI Project (.pbip) save option**, then restart Desktop.
2. Open `TCS_Financial_Dashboard.pbip`. It points to `TCS_Financial_Dashboard.Report`, whose `definition.pbir` has a relative `byPath` reference to `TCS_Financial_Dashboard.SemanticModel`.
3. Select **Refresh**. The semantic model already contains Power Query M partitions for `Historical Financials` and `Scenario Assumptions`, with the source workbook path set to `C:\Users\Sai Prasath D P\Downloads\ch (1).xlsx`.
4. If the workbook is moved, open **Transform data**, edit the `WorkbookPath` line in both queries, apply changes, then refresh.
5. The model contains historical measures plus a fixed `Forecast Model` table. FY2026 is an actual row. Base/Bull/Bear selection applies only to FY2027 and FY2028. The Executive KPI cards use `Forecast Revenue`, `Forecast EBITDA`, `Forecast Net Profit`, and `Forecast Free Cash Flow`, which map to Revenue, Calculated EBITDA proxy, Adjusted PAT, and Organic FCF.
6. If Power BI shows an **Apply external changes** banner after a source update, select it. Otherwise close the project without saving and reopen this `.pbip` file.
7. Save as a `.pbix` only if a single-file handoff is required; retain the entire project folder for PBIP development.

## Refresh reality

The supplied Excel workbook is a static snapshot, with source data stated as verified in April 2025. It cannot make a dashboard real-time by itself.

- **Near-real-time file refresh:** store the workbook in OneDrive for Business or SharePoint Online, connect Power BI to that cloud location, and let Power BI Service synchronize file changes. This is file-sync based, not streaming telemetry.
- **On-prem/local refresh:** keep the file local and configure a Power BI gateway plus a scheduled refresh. The machine/gateway must remain reachable.
- **True real-time:** replace the workbook source with an API/streaming source (for example, a market-data API through Azure Function/Eventstream) and use a push/streaming semantic model. That requires the selected data vendor, credentials, and Power BI Service capacity/licensing decision.

The PBIP semantic model and included query files are designed for the first two options. They are not a claim of real-time operation until a refresh mechanism is configured.

## Data checks

- Historical sheet: 12 core rows mapped across FY2018–FY2025.
- Scenario sheet: 10 parameters across Base Case, Bull Case, and Bear Case.
- No edits are made to the supplied workbook.

## Forecast sources and status

- Official FY2026 baseline: [TCS Integrated Annual Report 2025–26](https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2025-26/ar/annual-report-2025-2026.pdf)
- Official full-year context: [TCS FY2026 Q4/full-year results](https://www.tcs.com/who-we-are/newsroom/press-release/tcs-financial-results-q4-fy-2026)
- Current operating context: [TCS FY2027 Q1 results](https://www.tcs.com/who-we-are/newsroom/press-release/tcs-financial-results-q1-fy-2027)
- FY2027–FY2028 Base/Bull/Bear values are analytical sensitivity cases created for this dashboard. They are not TCS guidance, audited actuals, or consensus estimates.
