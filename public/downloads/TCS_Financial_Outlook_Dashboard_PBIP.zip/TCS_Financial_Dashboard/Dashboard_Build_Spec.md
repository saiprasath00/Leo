# Dashboard build specification

Use a 16:9 report page titled **TCS Financial Forecasting**. Apply INR crore display units and one decimal for percentages.

| Area | Visual | Fields / measures |
|---|---|---|
| Header | Text + refresh timestamp | “TCS Financial Forecasting”; show `Refresh date` from Power Query if added |
| Filters | Two slicers | `Scenario[Scenario]`; `Fiscal Years[Fiscal Year]` |
| KPI strip | Four cards | `Forecast Revenue`, `Forecast EBITDA`, `Forecast Net Profit`, `Forecast Free Cash Flow` |
| Trend | Line chart | Historical Revenue by `Fiscal Year Sort`; a second forecast line from a small forecast display table/field parameter |
| Scenarios | Clustered column chart | Revenue by Fiscal Year with Scenario as legend (use a scenario comparison calculation group or duplicate measures for Base/Bull/Bear) |
| Profitability | Combo chart | `Forecast EBITDA Margin`, net-profit margin derived from `Forecast Net Profit / Forecast Revenue` |
| Drivers | Matrix | `Scenario Assumptions[Parameter]`, `Scenario Assumptions[Value]`, filtered to selected scenario |
| Notes | Text box | “Forecasts are scenario-model outputs; FY2018–FY2025 are workbook historical data.” |

Set the scenario slicer to single select. Put the forecast-year slicer at FY2028 by default. The report is an analytical forecast dashboard, not market-price data.
