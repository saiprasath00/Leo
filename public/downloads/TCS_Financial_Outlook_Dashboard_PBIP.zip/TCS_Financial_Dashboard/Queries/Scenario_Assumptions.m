// Power Query: Scenario Assumptions
// Uses the same WorkbookPath parameter as Historical_Financials.m.
let
    Source = Excel.Workbook(File.Contents(WorkbookPath), null, true),
    AssumptionsSheet = Source{[Item="Assumptions", Kind="Sheet"]}[Data],
    HeaderRow = Table.PromoteHeaders(Table.Skip(AssumptionsSheet, 8), [PromoteAllScalars=true]),
    ParameterRows = Table.SelectRows(HeaderRow, each [Parameter] <> null),
    KeepColumns = Table.SelectColumns(ParameterRows, {"Parameter", "Base Case", "Bull Case", "Bear Case", "Unit", "Notes"}),
    Unpivoted = Table.Unpivot(KeepColumns, {"Base Case", "Bull Case", "Bear Case"}, "Scenario", "Value"),
    Typed = Table.TransformColumnTypes(Unpivoted, {{"Parameter", type text}, {"Scenario", type text}, {"Value", type number}, {"Unit", type text}, {"Notes", type text}}, "en-IN")
in
    Typed
