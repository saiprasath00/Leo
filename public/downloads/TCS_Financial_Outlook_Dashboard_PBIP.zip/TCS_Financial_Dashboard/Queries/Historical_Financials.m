// Power Query: Historical Financials
// Create a text parameter named WorkbookPath before running this query.
let
    Source = Excel.Workbook(File.Contents(WorkbookPath), null, true),
    HistoricalSheet = Source{[Item="Historical_Data", Kind="Sheet"]}[Data],
    HeaderRow = Table.PromoteHeaders(Table.Skip(HistoricalSheet, 3), [PromoteAllScalars=true]),
    CoreMetrics = Table.SelectRows(HeaderRow, each List.Contains({
        "Revenue", "EBITDA", "EBIT", "Other Income (Net)", "Net Profit",
        "EPS - Diluted (INR)", "Shares Outstanding", "Employees", "Depreciation",
        "Capex", "Free Cash Flow"
    }, [Particulars])),
    KeepColumns = Table.SelectColumns(CoreMetrics, {"Particulars", "FY2018", "FY2019", "FY2020", "FY2021", "FY2022", "FY2023", "FY2024", "FY2025", "Unit"}),
    Unpivoted = Table.UnpivotOtherColumns(KeepColumns, {"Particulars", "Unit"}, "Fiscal Year", "Amount"),
    Typed = Table.TransformColumnTypes(Unpivoted, {{"Particulars", type text}, {"Unit", type text}, {"Fiscal Year", type text}, {"Amount", type number}}, "en-IN"),
    AddedSort = Table.AddColumn(Typed, "Fiscal Year Sort", each Number.FromText(Text.AfterDelimiter([Fiscal Year], "FY")), Int64.Type)
in
    AddedSort
